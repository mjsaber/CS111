# true && echo good && echo good again || bad input
# false && echo bad || echo end test 1 
# sleep 2 && echo wakeup
# sleep 2 || echo wakeup
# ls | echo hello && grep test
# ls | grep test | grep p
# ls > b
# grep test < b > c
# echo testtest | grep test < b
# ls && echo testtest | grep test
# (ls && echo testtest) | grep test
# (ls | grep test) && echo hello
# (false; true) || echo hello
# echo nefpre && (false;echo hello)&& echo last
# (echo hello && ls) > b
# gcc adfsadfasfsadfsafdsafdsafdsaf || echo hello
# sort < b | grep test
# echo hello && sleep 3  && echo end
# echo hello2 && sleep 3 && echo end2
# (echo hi || false ;echo hi2) && echo end
# echo hi && sleep 3 && echo bye
# echo begin && sleep 3 && echo end
